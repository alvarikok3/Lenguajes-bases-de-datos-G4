package com.mycompany.lenguajesbd_g4;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class LenguajesBD_G4 {
    private static final Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) {
        System.out.println("====================================");
        System.out.println(" SISTEMA DE GESTIÓN DE BASE DE DATOS");
        System.out.println("====================================");
        System.out.println("Sistema de gestión para la verduleria. ");
        System.out.println("Curso: SC-504 Lenguajes de Base de Datos");
        System.out.println("=========\n");
        
        // Conexión al iniciar
        ConexionOracle.probarConexion();
        
        // Menú principal
        int opcion;
        do {
            mostrarMenu();
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer
            
            switch(opcion) {
                case 1:
                    ejecutarConsultaSimple();
                    break;
                case 2:
                    ejecutarProcedimientoAlmacenado();
                    break;
                case 3:
                    gestionarTablas();
                    break;
                case 4:
                    System.out.println("\nSaliendo del sistema...");
                    break;
                default:
                    System.out.println("\nOpción no válida. Intente nuevamente.");
            }
        } while(opcion != 4);
        
        scanner.close();
    }
    
    private static void mostrarMenu() {
        System.out.println("\n=== MENÚ PRINCIPAL ===");
        System.out.println("1. Ejecutar consulta simple");
        System.out.println("2. Ejecutar procedimiento almacenado");
        System.out.println("3. Gestionar tablas (CRUD)");
        System.out.println("4. Salir");
        System.out.print("Seleccione una opción: ");
    }
    
    private static void ejecutarConsultaSimple() {
        System.out.println("\n=== CONSULTA SIMPLE ===");
        System.out.print("Ingrese la consulta SQL: ");
        String consulta = scanner.nextLine();
        
        try (Connection conn = ConexionOracle.conectar();
             CallableStatement stmt = conn.prepareCall(consulta);
             ResultSet rs = stmt.executeQuery()) {
            
            System.out.println("\nResultados:");
            int columnCount = rs.getMetaData().getColumnCount();
            
            // Mostrar nombres de columnas
            for (int i = 1; i <= columnCount; i++) {
                System.out.printf("%-20s", rs.getMetaData().getColumnName(i));
            }
            System.out.println();
            
            // Mostrar datos
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    System.out.printf("%-20s", rs.getString(i));
                }
                System.out.println();
            }
            
        } catch (SQLException e) {
            System.err.println("Error al ejecutar consulta: " + e.getMessage());
        }
    }
    
    private static void ejecutarProcedimientoAlmacenado() {
        System.out.println("\n=== PROCEDIMIENTO ALMACENADO ===");
        System.out.print("Ingrese el nombre del procedimiento: ");
        String procedimiento = scanner.nextLine();
        
        try (Connection conn = ConexionOracle.conectar();
             CallableStatement stmt = conn.prepareCall("{call " + procedimiento + "}")) {
            
            System.out.println("Ejecutando procedimiento...");
            stmt.execute();
            System.out.println("Procedimiento ejecutado con éxito!");
            
        } catch (SQLException e) {
            System.err.println("Error al ejecutar procedimiento: " + e.getMessage());
        }
    }
    
    private static void gestionarTablas() {
        System.out.println("\n=== GESTIÓN DE TABLAS ===");
        System.out.println("1. Crear tabla");
        System.out.println("2. Insertar datos");
        System.out.println("3. Actualizar datos");
        System.out.println("4. Eliminar datos");
        System.out.println("5. Volver al menú principal");
        System.out.print("Seleccione una opción: ");
        
        int opcion = scanner.nextInt();
        scanner.nextLine();
        
        switch(opcion) {
            case 1:
                crearTabla();
                break;
            case 2:
                insertarDatos();
                break;
            case 3:
                actualizarDatos();
                break;
            case 4:
                eliminarDatos();
                break;
            default:
                System.out.println("Volviendo al menú principal...");
        }
    }
    
    private static void crearTabla() {
        System.out.println("\n=== CREAR TABLA ===");
        System.out.print("Ingrese el nombre de la tabla: ");
        String nombreTabla = scanner.nextLine();
        
        System.out.print("Ingrese la estructura (columnas y tipos): ");
        String estructura = scanner.nextLine();
        
        String sql = "CREATE TABLE " + nombreTabla + " (" + estructura + ")";
        
        try (Connection conn = ConexionOracle.conectar();
             CallableStatement stmt = conn.prepareCall(sql)) {
            
            stmt.execute();
            System.out.println("Tabla creada con éxito!");
            
        } catch (SQLException e) {
            System.err.println("Error al crear tabla: " + e.getMessage());
        }
    }
    
    private static void insertarDatos() {
        System.out.println("\n=== INSERTAR DATOS ===");
        System.out.print("Ingrese el nombre de la tabla: ");
        String tabla = scanner.nextLine();
        
        System.out.print("Ingrese los nombres de las columnas (separados por comas): ");
        String columnas = scanner.nextLine();
        
        System.out.print("Ingrese los valores (separados por comas): ");
        String valores = scanner.nextLine();
        
        String sql = "INSERT INTO " + tabla + " (" + columnas + ") VALUES (" + valores + ")";
        
        try (Connection conn = ConexionOracle.conectar();
             CallableStatement stmt = conn.prepareCall(sql)) {
            
            int filas = stmt.executeUpdate();
            System.out.println(filas + " fila(s) insertada(s) con éxito!");
            
        } catch (SQLException e) {
            System.err.println("Error al insertar datos: " + e.getMessage());
        }
    }
    
    private static void actualizarDatos() {
        System.out.println("\n=== ACTUALIZAR DATOS ===");
        System.out.print("Ingrese el nombre de la tabla: ");
        String tabla = scanner.nextLine();
        
        System.out.print("Ingrese la asignación de valores (ej: columna1=valor1, columna2=valor2): ");
        String valores = scanner.nextLine();
        
        System.out.print("Ingrese la condición WHERE (opcional): ");
        String condicion = scanner.nextLine();
        
        String sql = "UPDATE " + tabla + " SET " + valores;
        if (!condicion.isEmpty()) {
            sql += " WHERE " + condicion;
        }
        
        try (Connection conn = ConexionOracle.conectar();
             CallableStatement stmt = conn.prepareCall(sql)) {
            
            int filas = stmt.executeUpdate();
            System.out.println(filas + " fila(s) actualizada(s) con éxito!");
            
        } catch (SQLException e) {
            System.err.println("Error al actualizar datos: " + e.getMessage());
        }
    }
    
    private static void eliminarDatos() {
        System.out.println("\n=== ELIMINAR DATOS ===");
        System.out.print("Ingrese el nombre de la tabla: ");
        String tabla = scanner.nextLine();
        
        System.out.print("Ingrese la condición WHERE (opcional): ");
        String condicion = scanner.nextLine();
        
        String sql = "DELETE FROM " + tabla;
        if (!condicion.isEmpty()) {
            sql += " WHERE " + condicion;
        }
        
        try (Connection conn = ConexionOracle.conectar();
             CallableStatement stmt = conn.prepareCall(sql)) {
            
            int filas = stmt.executeUpdate();
            System.out.println(filas + " fila(s) eliminada(s) con éxito!");
            
        } catch (SQLException e) {
            System.err.println("Error al eliminar datos: " + e.getMessage());
        }
    }
}