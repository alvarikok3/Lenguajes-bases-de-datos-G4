package com.mycompany.lenguajesbd_g4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
//@utor:Grupo 4

public class ConexionOracle {

    private static final Logger logger = Logger.getLogger(ConexionOracle.class.getName());

    // Configuración de conexión 
    private static final String URL = "jdbc:oracle:thin:@localhost:1521:XE";
    private static final String USER = "system";
    private static final String PASSWORD = "12345";

    // Registro el driver
    static {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException ex) {
            logger.log(Level.SEVERE, "Error al cargar el driver JDBC de Oracle", ex);
            System.exit(1);
        }
    }

    /**
     * Establece conexión con la base de datos Oracle
     *
     * @return Connection objeto de conexión
     * @throws SQLException si ocurre un error al conectar
     */
    public static Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    /**
     * Prueba de la conexión y muestra información de la base de datos
     */
    public static void probarConexion() {
        try (Connection conn = conectar()) {
            System.out.println("\n=== CONEXIÓN EXITOSA ===");
            System.out.println("🔹 Base de datos: " + conn.getMetaData().getDatabaseProductName());
            System.out.println("🔹 Versión: " + conn.getMetaData().getDatabaseProductVersion());
            System.out.println("🔹 Usuario: " + conn.getMetaData().getUserName());
            System.out.println("🔹 URL: " + conn.getMetaData().getURL());
            System.out.println("========================\n");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error al conectar con la base de datos", e);
            System.err.println("\n=== ERROR DE CONEXIÓN ===");
            System.err.println("Código: " + e.getErrorCode());
            System.err.println("Estado: " + e.getSQLState());
            System.err.println("Mensaje: " + e.getMessage());
            System.err.println("============\n");
        }
    }
}
